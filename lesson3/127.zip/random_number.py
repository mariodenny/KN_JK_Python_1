"""
                KODINGNEXT PROJECT
                DATE : 2024-11-16
                RANDOM NUMBER
"""
# We are going to use random number generator module. To use it import to the project
# Import random module
import  random
# Initialize variable
my_lucky_number = random.randrange(1,100)
# Print my lucky number
print(f"my lucky number today is {my_lucky_number}")

