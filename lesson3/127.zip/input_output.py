"""
                NAME : KODINGNEXT
                DATE : 2024-11-16
                PROJECT : INPUT & OUTPUT
"""
# Create simple input to input our name and display it

your_name = input("Input your name : ")
your_age = input("Input your age : ")
your_gender = input("Input your gender : ")

print(f"Name : {your_name}")
print(f"Age : {your_age}")
print(f"Gender : {your_gender}")


