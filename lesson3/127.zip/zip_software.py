"""
                NAME : KODINGNEXT
                DATE : 2024-11-16
                PROJECT : Zip program

"""
# Make simple zipper software, or zip compressor

from shutil import  make_archive
import  random

zip_filename = random.randrange(100,200)

folder_to_zip = input("Input your file: ")
make_archive(f"{zip_filename}","zip",folder_to_zip)